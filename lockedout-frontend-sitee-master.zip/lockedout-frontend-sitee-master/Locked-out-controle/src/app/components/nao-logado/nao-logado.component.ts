import { Component } from '@angular/core';

@Component({
  selector: 'nao-logado',
  templateUrl: './nao-logado.component.html',
  styleUrls: ['./nao-logado.component.scss']
})
export class NaoLogadoComponent {

}
