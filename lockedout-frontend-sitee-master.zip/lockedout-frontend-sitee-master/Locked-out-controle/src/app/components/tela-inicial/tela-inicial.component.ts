import { Component, ViewChild } from '@angular/core';
import { autorizadoGuard } from 'src/app/util/guard/autorizado.guard';

@Component({
  selector: 'app-tela-inicial',
  templateUrl: './tela-inicial.component.html',
  styleUrls: ['./tela-inicial.component.scss']
})

export class TelaInicialComponent {}