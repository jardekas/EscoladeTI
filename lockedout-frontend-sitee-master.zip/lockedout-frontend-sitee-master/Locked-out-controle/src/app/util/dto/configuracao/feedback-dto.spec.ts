import { FeedbackDTO } from './feedback-dto';

describe('FeedbackDTO', () => {
  it('should create an instance', () => {
    expect(new FeedbackDTO()).toBeTruthy();
  });
});
