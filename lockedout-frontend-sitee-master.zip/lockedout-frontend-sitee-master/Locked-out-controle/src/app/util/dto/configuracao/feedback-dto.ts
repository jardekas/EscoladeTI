export class FeedbackDTO {
    feedback !: string;
}
