export class UpdateUserDTO {
    idUser !: number;
    email !: string;
    telefone !: string;
    notificacao !: number;
    senha !: boolean
}
