import { UpdateUserDTO } from './update-user-dto';

describe('UpdateUserDTO', () => {
  it('should create an instance', () => {
    expect(new UpdateUserDTO()).toBeTruthy();
  });
});
