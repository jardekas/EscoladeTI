export class BloqueioRespostaDTO {
    idBloqueio !: number;
    url !: string;
    diaInicio !: string;
    diaFim !: string;
    horarioInicio !: string;
    horarioFim !: string;
}
