import { BloqueioRespostaDTO } from './bloqueio-resposta-dto';

describe('BloqueioRespostaDTO', () => {
  it('should create an instance', () => {
    expect(new BloqueioRespostaDTO()).toBeTruthy();
  });
});
