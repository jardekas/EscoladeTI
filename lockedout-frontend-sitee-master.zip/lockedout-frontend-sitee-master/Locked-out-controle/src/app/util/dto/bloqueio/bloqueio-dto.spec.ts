import { BloqueioDTO } from './bloqueio-dto';

describe('BloqueioDTO', () => {
  it('should create an instance', () => {
    expect(new BloqueioDTO()).toBeTruthy();
  });
});
