export class BloqueioDeleteDTO {
    idBloqueio !: number;
}
