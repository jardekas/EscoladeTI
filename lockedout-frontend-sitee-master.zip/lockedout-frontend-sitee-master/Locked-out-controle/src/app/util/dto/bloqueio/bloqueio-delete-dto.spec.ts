import { BloqueioDeleteDTO } from './bloqueio-delete-dto';

describe('BloqueioDeleteDTO', () => {
  it('should create an instance', () => {
    expect(new BloqueioDeleteDTO()).toBeTruthy();
  });
});
