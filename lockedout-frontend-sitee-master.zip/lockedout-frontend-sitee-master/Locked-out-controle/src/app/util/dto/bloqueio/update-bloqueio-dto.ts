export class UpdateBloqueioDTO {
    idBloqueio !: number;
    url !: string;
    diaInicio !: Date;
    diaFim !: Date;
    tempoInicio !: string;
    tempoFim !: string;
}
