import { UpdateBloqueioDTO } from './update-bloqueio-dto';

describe('UpdateBloqueioDTO', () => {
  it('should create an instance', () => {
    expect(new UpdateBloqueioDTO()).toBeTruthy();
  });
});
