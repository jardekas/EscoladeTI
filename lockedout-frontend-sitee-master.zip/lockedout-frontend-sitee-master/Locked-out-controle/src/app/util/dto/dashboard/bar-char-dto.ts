export class BarCharDTO {
 data !: number
 total!: number 
}
