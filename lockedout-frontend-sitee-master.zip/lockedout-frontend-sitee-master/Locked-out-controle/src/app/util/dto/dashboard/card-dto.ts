export class CardDTO {
    url !: string 
    tempoAcesso !: string
    qtdAcesso !: number 
}
