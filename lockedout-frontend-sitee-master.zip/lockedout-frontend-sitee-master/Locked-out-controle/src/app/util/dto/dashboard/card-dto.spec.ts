import { CardDTO } from './card-dto';

describe('CardDTO', () => {
  it('should create an instance', () => {
    expect(new CardDTO()).toBeTruthy();
  });
});
