import { BarChartVerticalDTO } from './bar-chart-vertical-dto';

describe('BarChartVerticalDTO', () => {
  it('should create an instance', () => {
    expect(new BarChartVerticalDTO()).toBeTruthy();
  });
});
