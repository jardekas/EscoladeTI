export class LineCharDTO {
    mes !: number 
    qtdHoras !: number 
}
