export class DoughnutDTO {
    total !: number 
    horario !: string 
}
