import { DoughnutDTO } from './doughnut-dto';

describe('DoughnutDTO', () => {
  it('should create an instance', () => {
    expect(new DoughnutDTO()).toBeTruthy();
  });
});
