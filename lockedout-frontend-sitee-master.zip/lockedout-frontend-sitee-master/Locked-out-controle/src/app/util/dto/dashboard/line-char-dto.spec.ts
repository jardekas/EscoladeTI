import { LineCharDTO } from './line-char-dto';

describe('LineCharDTO', () => {
  it('should create an instance', () => {
    expect(new LineCharDTO()).toBeTruthy();
  });
});
