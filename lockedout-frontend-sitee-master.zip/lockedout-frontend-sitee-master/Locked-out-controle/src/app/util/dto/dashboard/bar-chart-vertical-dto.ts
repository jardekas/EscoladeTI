export class BarChartVerticalDTO {
    bloquado !: boolean
    qtdTotal !: number
}
