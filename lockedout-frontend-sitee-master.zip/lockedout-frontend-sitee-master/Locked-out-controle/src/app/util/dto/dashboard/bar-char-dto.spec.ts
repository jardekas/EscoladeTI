import { BarCharDTO } from './bar-char-dto';

describe('BarCharDTO', () => {
  it('should create an instance', () => {
    expect(new BarCharDTO()).toBeTruthy();
  });
});
