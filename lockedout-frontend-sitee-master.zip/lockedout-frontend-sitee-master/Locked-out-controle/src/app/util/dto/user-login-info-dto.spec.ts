import { UserLoginInfoDTO } from './user-login-info-dto';

describe('UserLoginInfoDTO', () => {
  it('should create an instance', () => {
    expect(new UserLoginInfoDTO()).toBeTruthy();
  });
});
