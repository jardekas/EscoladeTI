export class HistoricoEnvioDTO {
    idHistorico !: number;
    url !: string;
    data !: string;
    tempo !: string;
    siteBloqueado !: boolean;
}
