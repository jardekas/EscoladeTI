import { HistoricoEnvioDTO } from './historico-envio-dto';

describe('HistoricoEnvioDTO', () => {
  it('should create an instance', () => {
    expect(new HistoricoEnvioDTO()).toBeTruthy();
  });
});
