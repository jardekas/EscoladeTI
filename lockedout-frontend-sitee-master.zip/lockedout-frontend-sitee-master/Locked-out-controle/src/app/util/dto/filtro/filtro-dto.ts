export class FiltroDTO {
    filtro !: string;
}
