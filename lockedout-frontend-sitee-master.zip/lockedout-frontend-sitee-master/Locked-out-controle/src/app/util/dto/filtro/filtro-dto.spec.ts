import { FiltroDTO } from './filtro-dto';

describe('FiltroDTO', () => {
  it('should create an instance', () => {
    expect(new FiltroDTO()).toBeTruthy();
  });
});
