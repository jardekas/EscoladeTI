import { PerfilDTO } from './perfil-dto';

describe('PerfilDTO', () => {
  it('should create an instance', () => {
    expect(new PerfilDTO()).toBeTruthy();
  });
});
