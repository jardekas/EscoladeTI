export class PerfilDTO {
    email !: string;
    telefone !: string;
    dataNascimento !: string;
    tipoNotificacao !: string;
    tipoSenha !: string;
}
