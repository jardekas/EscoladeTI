export class UserLoginInfoDTO {
    idUser !: number
}
