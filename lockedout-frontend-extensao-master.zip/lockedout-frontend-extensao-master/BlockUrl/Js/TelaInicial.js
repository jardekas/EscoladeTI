document.querySelector("#btnCadastrar").addEventListener("click", function() {
    window.location.href = "Telacadastro.html";
});

document.querySelector("#btnLogin").addEventListener("click", function() {
    window.location.href = "login.html";
});
