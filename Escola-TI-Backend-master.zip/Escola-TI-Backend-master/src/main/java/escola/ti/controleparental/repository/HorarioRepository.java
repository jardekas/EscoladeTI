package escola.ti.controleparental.repository;

import org.springframework.data.repository.CrudRepository;

import escola.ti.controleparental.model.HorarioModel;

public interface HorarioRepository extends CrudRepository<HorarioModel, Integer> {}

