package escola.ti.controleparental.repository;

import org.springframework.data.repository.CrudRepository;

import escola.ti.controleparental.model.HistoricoModel;

public interface HistoricoRepository extends CrudRepository<HistoricoModel, Integer> {}
