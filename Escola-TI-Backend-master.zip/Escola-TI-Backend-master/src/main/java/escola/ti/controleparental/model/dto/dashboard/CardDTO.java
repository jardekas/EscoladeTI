package escola.ti.controleparental.model.dto.dashboard;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class CardDTO {
    private String  url;
    private String  tempoAcesso;
    private Integer qtdAcesso;
}
