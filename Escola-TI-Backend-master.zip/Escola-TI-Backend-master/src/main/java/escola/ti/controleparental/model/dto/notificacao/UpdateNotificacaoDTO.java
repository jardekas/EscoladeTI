package escola.ti.controleparental.model.dto.notificacao;

import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class UpdateNotificacaoDTO {
    private Integer idUser;
    private Integer tipoNotificacao;
}
