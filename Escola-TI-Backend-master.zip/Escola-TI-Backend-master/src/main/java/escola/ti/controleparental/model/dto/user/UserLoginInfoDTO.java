package escola.ti.controleparental.model.dto.user;

import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class UserLoginInfoDTO {
    private Integer idUser;
}
    