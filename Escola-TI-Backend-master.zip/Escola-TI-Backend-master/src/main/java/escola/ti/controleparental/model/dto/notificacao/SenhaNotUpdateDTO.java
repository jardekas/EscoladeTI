package escola.ti.controleparental.model.dto.notificacao;

import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class SenhaNotUpdateDTO {
    private Integer idUser;
    private Boolean tipoSenha;
}
