package escola.ti.controleparental.model.dto.configuracao;

import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class FeedbackDTO {
    private String feedback;
}
