package escola.ti.controleparental.model.dto.dashboard;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class DoughnutDTO {
    private Integer total;
    private String horario;
}
