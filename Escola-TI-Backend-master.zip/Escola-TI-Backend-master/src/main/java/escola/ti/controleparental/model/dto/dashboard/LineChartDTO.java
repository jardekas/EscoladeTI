package escola.ti.controleparental.model.dto.dashboard;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class LineChartDTO {
    private Integer mes;
    private Float qtdHoras;
}
