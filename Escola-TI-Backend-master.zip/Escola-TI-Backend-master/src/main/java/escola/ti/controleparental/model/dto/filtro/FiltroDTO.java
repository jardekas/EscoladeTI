package escola.ti.controleparental.model.dto.filtro;

import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class FiltroDTO {
    private String filtro;
}
