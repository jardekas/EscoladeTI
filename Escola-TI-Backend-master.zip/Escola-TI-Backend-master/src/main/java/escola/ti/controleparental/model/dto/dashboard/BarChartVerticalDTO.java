package escola.ti.controleparental.model.dto.dashboard;

import lombok.Getter;
import lombok.Setter;

@Getter@Setter
public class BarChartVerticalDTO {
    private Boolean bloquado;
    private Integer qtdTotal;
}
