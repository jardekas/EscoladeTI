package escola.ti.controleparental.model.dto.historico;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class TimerDTO {
    private Integer idHorario;
    private String tempo;
}
