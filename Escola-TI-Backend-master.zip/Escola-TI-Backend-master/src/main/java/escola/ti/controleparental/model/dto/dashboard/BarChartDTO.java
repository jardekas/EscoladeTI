package escola.ti.controleparental.model.dto.dashboard;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
@AllArgsConstructor
public class BarChartDTO {
    private Integer data;
    private Integer total;
}
