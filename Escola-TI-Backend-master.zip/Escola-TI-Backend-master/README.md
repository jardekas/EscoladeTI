Backend do projeto da Escola de TI - Locked-Out
